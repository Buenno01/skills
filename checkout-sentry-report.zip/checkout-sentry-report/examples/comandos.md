# Exemplos de comandos

Rode a partir da pasta da skill (onde está o `SKILL.md`). Pela skill, passe os argumentos e, se quiser, o pedido em texto, ex.: `/checkout-sentry-report export.csv --clientes clientes/ --currency 'R$' e monte um resumo para o cliente`.

## Básico

```
python3 scripts/indicadores.py checkouts-export-30d.csv --clientes clientes/
```

Moeda `$`, fuso UTC. Imprime avisos, a tabela de indicadores e as notas de método.

## Moeda e fuso

```
python3 scripts/indicadores.py checkouts.csv --clientes clientes/ --currency 'R$' --tz America/Sao_Paulo
python3 scripts/indicadores.py checkouts.csv --clientes clientes/ --currency 'US$' --tz America/New_York
python3 scripts/indicadores.py checkouts.csv --clientes clientes/ --currency '€' --tz Europe/Lisbon
```

Use aspas simples para o shell não interpretar o `$`. Só o símbolo muda; os valores não são convertidos.

## Base de clientes em um único CSV

```
python3 scripts/indicadores.py checkouts.csv --clientes customers_export.csv
```

## UF conta como entrega

```
python3 scripts/indicadores.py checkouts.csv --clientes clientes/ --uf-conta-entrega
```

## Dados completos para montar gráficos, planilhas ou páginas

```
python3 scripts/indicadores.py checkouts.csv --clientes clientes/ --json metricas.json --csv indicadores.csv
```

`metricas.json` tem as listas linha a linha (cupons, checkouts com erro de frete). `indicadores.csv` tem a tabela plana com valores brutos, pronta para planilha.

## Reaproveitar um cálculo

```
python3 scripts/indicadores.py --de-json metricas.json --currency 'R$'
```

Não relê os CSVs: reimprime a tabela a partir do JSON. `--currency` sobrescreve a moeda gravada.

## Via skill

```
/checkout-sentry-report checkouts.csv --clientes clientes/
/checkout-sentry-report checkouts.csv --clientes clientes/ --currency 'R$' --tz America/Sao_Paulo quero uma planilha
/checkout-sentry-report os arquivos estão nessa pasta, a moeda é Real, me diga onde está o maior valor perdido
```

---
name: checkout-sentry-report
description: Processa um export CSV do Checkout Sentry cruzado com a base de clientes Shopify e devolve a tabela completa de indicadores de checkouts, abandono, opt-ins, valor recuperável e erros (frete, cupom, pagamento). Os números saem de um script determinístico; o agente decide como apresentar (resposta no chat, planilha, slide, página, e-mail, análise).
disable-model-invocation: true
argument-hint: "<csv de checkouts> --clientes <pasta ou csv> [--currency SÍMBOLO] [--tz FUSO] [--uf-conta-entrega] [--json JSON] [--csv CSV] | --de-json JSON  + o que você quer como resultado"
---

Esta skill é a camada de dados. Todo número vem de `scripts/indicadores.py`, que lê os CSVs, cruza com a base e imprime uma tabela de indicadores. O script não gera apresentação nenhuma. O formato final (resposta em texto, tabela no chat, planilha, deck, página, e-mail, recomendação) é decisão sua, a partir do que o usuário pediu em `$ARGUMENTS` ou na conversa.

Requer Python 3.9+ e só a biblioteca padrão.

## Entradas

1. **CSV de checkouts** exportado do Checkout Sentry, com as colunas `Status`, `Checkout Token`, `Client ID`, `Email`, `Nome`, `Telefone`, `Cidade`, `UF`, `Valor`, `Última atividade`, `Entrou em`, `Tipo de erro`, `Mensagem de erro`. Se o nome do arquivo tiver `NNd` (ex.: `30d`), o script compara com o período real e avisa quando o export está curto ou truncado.
2. **Base de clientes** (`--clientes`): uma pasta com CSVs ou um único CSV no formato de export de clientes da Shopify, com `Customer ID`, `Email`, `Phone`, `Default Address Phone`, `Accepts Email Marketing`, `Accepts SMS Marketing`, `Accepts WhatsApp Marketing`. Deduplicada por `Customer ID`.

Se faltar coluna, o script para com `ERRO:` e diz qual.

## Parâmetros

`$ARGUMENTS` pode trazer caminhos, flags e também o pedido do usuário em linguagem natural (ex.: "a moeda é Real, faça um resumo para o cliente"). Traduza o pedido em flags quando houver correspondência direta (Real → `--currency 'R$'`) e guarde o resto para decidir a apresentação. Se o usuário não disser o fuso, use o padrão e diga qual foi usado.

| Parâmetro | Efeito | Padrão |
|---|---|---|
| `<csv>` (posicional) | CSV do Checkout Sentry | obrigatório (exceto com `--de-json`) |
| `--clientes PASTA_OU_CSV` | Base de clientes | obrigatório com o CSV |
| `--currency SÍMBOLO` | Símbolo da moeda nos valores formatados. Só muda o rótulo, não converte | `$` |
| `--tz FUSO` | Fuso IANA para datas e horas (ex.: `America/Sao_Paulo`) | `UTC` |
| `--uf-conta-entrega` | UF sozinha conta como "após preencher entrega" | não conta |
| `--json JSON` | Grava as métricas completas, incluindo listas linha a linha | não grava |
| `--csv CSV` | Grava a tabela plana de indicadores com valores brutos | não grava |
| `--de-json JSON` | Reimprime a tabela a partir de um JSON gravado antes, sem recalcular. Aceita `--currency` e `--csv` | — |

Exemplos em `examples/comandos.md`.

## Passos

1. **Confirmar as entradas.** O CSV de checkouts e a base de clientes precisam existir. Se faltar um deles, peça ao usuário; não invente caminhos.

2. **Rodar**, a partir da pasta desta skill:
   ```
   python3 scripts/indicadores.py <csv> --clientes <pasta_ou_csv> [flags]
   ```
   Se o resultado final precisar de listas completas (todas as mensagens de cupom, cada checkout com erro de frete) ou de um gráfico/arquivo, acrescente `--json` com um caminho no scratchpad. Se sair `ERRO:`, mostre a mensagem e pare.

3. **Ler a saída.** O stdout tem, nesta ordem:
   - linhas `JSON:` / `CSV:` com os caminhos gravados, se pedidos;
   - linhas `AVISO:` (recorte curto ou truncado);
   - `## Indicadores`: tabela Markdown com `Grupo | Chave | Indicador | Valor | % | Base do %`;
   - `## Notas de método`: definições usadas no cálculo.

4. **Entregar no formato pedido.** Se o usuário não disse o formato, responda no chat com os indicadores principais (resumo, etapas, quem abandonou, erros dos recuperáveis) e ofereça outros formatos. Se ele pediu um arquivo ou página, siga as skills de identidade visual e de escrita aplicáveis.

## Regras de fidelidade aos dados

- **Não recalcule.** Use os valores e percentuais da tabela exatamente como saem. Se precisar de um número que não está na tabela, calcule a partir do JSON e diga que é derivado.
- **Respeite a base do %.** Cada percentual tem a sua base (`checkouts`, `abandonados`, `valor abandonado`, `recuperáveis` etc.). Nunca troque a base ao reescrever ("37,9% dos abandonados" não é "37,9% dos checkouts").
- **Leve os avisos junto.** Se houver `AVISO:`, ele aparece em qualquer entrega, perto dos números.
- **Cite a chave** quando o usuário perguntar de onde veio um número, para ser rastreável.
- **Sem dados pessoais.** O script não expõe e-mail, nome nem telefone. Não os busque nos CSVs para montar listas.

## JSON (`--json`)

Mesmos números da tabela, em formato estruturado, mais:
- `indicadores`: a tabela plana (lista de objetos com `grupo`, `chave`, `indicador`, `tipo`, `valor`, `pct`, `base_pct`). `valor` e `pct` são brutos (`pct` de 0 a 100); `tipo` é `qtd`, `moeda`, `dias` ou `data`.
- `anexo.cupons`: todas as mensagens de erro de cupom, exatamente como o checkout exibiu, com tentativas e abandonos.
- `anexo.frete_checkouts`: cada checkout com erro de frete (token curto, status, recuperável, cidade, UF, valor, mudanças de endereço, mensagem).
- `anexo.pagamento` e `anexo.frete`: erros por mensagem.
- `por_dia`, `etapas`, `erros_recuperaveis`, `recuperaveis_detalhe` etc., com os números brutos.
- `avisos` e `notas_metodo`.

## Definições principais

- **Abandonado:** status `abandonado` ou `com_erro`.
- **Recuperável:** abandonado cujo cliente (cruzado por e-mail ou, se não achar, por telefone) tem opt-in em ao menos um canal.
- As demais regras (etapas, frete, cupom, pagamento, empates no top 5) estão nas notas de método da saída.

## Testes

```
cd scripts && python3 -m unittest discover .
```

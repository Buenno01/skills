# Raio-X do checkout: padrões

## Identidade visual

A página segue a skill `identidade-visual-shakers`: Poppins (300, 400, 600, 700), fundo branco dominante, texto em
preto, cabeçalho em gradiente Mint claro, barra verde sob o título, cards com raio 14 px e borda `#ECECEC`,
espaçamento em múltiplos de 8. Não há fundo preto em nenhum bloco.

## Cores semânticas de dado

Gráfico de relatório precisa comunicar estado. Por isso as barras não usam preto nem cinza, e a paleta inclui
vermelho e amarelo como cores semânticas, mesmo onde a marca não prevê esse uso.

| Papel | Token CSS | Barra | Texto | Fundo | Uso |
|---|---|---|---|---|---|
| Concluiu, positivo | `--concluiu` | `#22C76A` | `#117A41` | `#E6FAEF` | Checkouts concluídos, recuperáveis com opt-in, canal ativo |
| Crítico | `--critico` | `#E5484D` | `#C92A2A` | `#FDECEC` | Abandonou, maior queda do funil, fora da base |
| Atenção | `--atencao` | `#F4B619` | `#8A6100` | `#FEF6DC` | Amostra pequena, avisos de coleta, na base sem opt-in, canal sem coleta de opt-in |
| Dado neutro | `--dado` | `#2461E8` | `#2461E8` | `#E3EBFD` | Contagens sem juízo (funil, média geral), parte "concluiu ou anônimo" |
| Outros | `--outros` | `#8B5CF6` | | `#EFE8FE` | Anônimo ou em andamento na tendência |

Verde é sempre concluiu, vermelho é sempre abandonou. Não inverta nem reaproveite essas cores para outra coisa.

## Convenções de apresentação

- Barras empilhadas para comparar categorias (concluiu × abandonou). A largura da barra é o volume relativo ao maior grupo, e o número à direita é a taxa de abandono.
- Barras simples para contagens. Quando importa quantos daqueles abandonaram, o trecho vermelho mostra essa parte.
- Médias (ticket, frete) em barras lado a lado, nunca empilhadas.
- Amostra pequena (menos de 5 checkouts com desfecho): barra e taxa esmaecidas e pílula amarela "amostra pequena".
- Todo gráfico mostra todas as linhas. Com mais de 25, a lista ganha rolagem interna, nunca corte. A tabela recolhível traz os números completos.
- Textos que vêm dos dados (produto, frete, cupom, mensagem de erro, UF, método) aparecem como vieram, sem reescrita nem categoria criada por texto.
- Tooltip com os detalhes ao passar o mouse.
- Valores em dinheiro com o rótulo de `fonte.moeda` (padrão `$` quando a moeda não é conhecida). Acima de mil, sem centavos.

## Escrita da narrativa

Vale a skill `escrita-padrao-shakers`. Pontos que o `montar.py` confere ou que mais aparecem neste relatório:

- **Título é conclusão.** Frase com verbo que diz o que o dado mostra. Até 100 caracteres.
- **Contexto explica o porquê e o que fazer.** Uma a três frases, até 420 caracteres. Cite no máximo dois números, e só números que o template mostra na seção.
- **Sem travessão** como recurso de estilo (o `montar.py` recusa `—` e `–`). Use vírgula, dois pontos ou ponto.
- **Sem dado pessoal.** Nada de nome, e-mail ou telefone (o `montar.py` recusa padrões de e-mail e telefone).
- **Honestidade.** Taxa com amostra pequena não vira conclusão. Frete e ticket se misturam: diga isso quando comparar frete grátis e pago. Período curto ou coleta parcial aparecem no cabeçalho e, quando mudam a leitura, no contexto.
- **Seção sem dado** (nenhum erro de cupom, nenhum alerta de formulário): o título diz que não houve ocorrência no período. Isso também é resultado.
- **Sem nomes específicos no texto fixo.** A narrativa pode citar um produto, frete, cupom ou UF que aparece nos dados do relatório. Nunca escreva regra, exemplo ou referência de loja, marca ou produto nas skills.

"""Gate de entrada do Raio-X do checkout. Nada é calculado sem as duas entradas válidas.

Uso:
    python3 validar.py [--checkouts ARQUIVO.json] [--clientes CSV_OU_PASTA] [--raiz DIR]

Sem caminhos, procura nos anexos da conversa (/mnt/user-data/uploads) e na raiz do projeto
(Análises/CheckoutSentry/ e BaseDeClientes/).

Saída (uma informação por linha, sem dados pessoais):
    CHECKOUTS: <caminho> | loja=... | periodo=... | exportado_em=... | checkouts=N/M
    OUTROS_CHECKOUTS: <caminho>          (candidatos não escolhidos, se houver)
    MOEDA_NO_ARQUIVO: <valores>         (só se algum checkout tiver um campo de moeda)
    CLIENTES: <caminho> | arquivos=N | cadastros=N
    KPIS_SCRIPT: <caminho do kpis.py da skill gerar-relatorio-checkout-sentry-json>
    OK
Códigos de saída: 0 = pronto; 2 = falta entrada (pedir ao usuário); 3 = entrada inválida; 4 = dependência ausente.
"""
import argparse
import csv
import glob
import json
import os
import sys
import tempfile

UPLOADS = '/mnt/user-data/uploads'
# Assinatura do JSON gravado por coletar-checkouts-sentry (scripts/coletarCheckouts.js)
TOPO = ['shop', 'period', 'exported_at', 'total_disponivel', 'total_coletado', 'checkouts']
CHK = ['status', 'checkout_token', 'client_id', 'email', 'phone', 'province', 'payment_method', 'cart_value',
       'cart_items', 'events', 'error_type', 'error_message', 'first_event_at', 'last_event_at']
# Colunas do export de clientes da Shopify usadas no cruzamento
CLI = ['Customer ID', 'Email', 'Phone', 'Default Address Phone', 'Accepts Email Marketing',
       'Accepts SMS Marketing', 'Accepts WhatsApp Marketing', 'Total Orders']


def falta(msg):
    print(f'FALTA: {msg}')
    sys.exit(2)


def invalido(msg):
    print(f'INVALIDO: {msg}')
    sys.exit(3)


def checar_checkouts(path):
    """Devolve o resumo se o arquivo for o JSON da coletar-checkouts-sentry; senão, a razão da recusa."""
    if not path.lower().endswith('.json'):
        return None, 'não é .json (o Raio-X aceita só o JSON gravado pela skill coletar-checkouts-sentry)'
    try:
        with open(path, encoding='utf-8-sig') as f:
            d = json.load(f)
    except (OSError, json.JSONDecodeError) as err:
        return None, f'não é um JSON válido ({err})'
    if not isinstance(d, dict):
        return None, 'o JSON não é um objeto com a chave "checkouts"'
    sem = [k for k in TOPO if k not in d]
    if sem:
        return None, 'não tem a assinatura da coletar-checkouts-sentry (faltam: ' + ', '.join(sem) + ')'
    lista = d.get('checkouts') or []
    if not isinstance(lista, list) or not lista:
        return None, 'a lista "checkouts" está vazia'
    campos = [k for k in CHK if not any(isinstance(c, dict) and k in c for c in lista)]
    if campos:
        return None, 'checkouts sem os campos esperados: ' + ', '.join(campos)
    # moeda só a partir de campo estruturado do próprio checkout (qualquer chave com "currency")
    moedas = sorted({str(v) for c in lista if isinstance(c, dict) for k, v in c.items()
                     if 'currency' in k.lower() and isinstance(v, str) and v.strip()})
    return {'loja': d.get('shop'), 'periodo': d.get('period'), 'exportado_em': d.get('exported_at'),
            'coletado': d.get('total_coletado'), 'disponivel': d.get('total_disponivel'), 'n': len(lista),
            'moedas': moedas}, None


def cabecalho_csv(path):
    try:
        with open(path, encoding='utf-8-sig', newline='') as f:
            return next(csv.reader(f), [])
    except (OSError, UnicodeDecodeError):
        return []


def eh_clientes(path):
    cab = cabecalho_csv(path)
    return all(c in cab for c in CLI), [c for c in CLI if c not in cab]


def contar_linhas(paths):
    n = 0
    for p in paths:
        with open(p, encoding='utf-8-sig', newline='') as f:
            n += max(0, sum(1 for _ in csv.reader(f)) - 1)
    return n


def achar_kpis(raiz):
    aqui = os.path.dirname(os.path.abspath(__file__))
    cands = [os.path.join(aqui, '..', '..', 'gerar-relatorio-checkout-sentry-json', 'scripts', 'kpis.py'),
             os.path.join(raiz, '.claude', 'skills', 'gerar-relatorio-checkout-sentry-json', 'scripts', 'kpis.py'),
             os.path.expanduser('~/.claude/skills/gerar-relatorio-checkout-sentry-json/scripts/kpis.py')]
    cands += glob.glob('/mnt/skills/*/gerar-relatorio-checkout-sentry-json/scripts/kpis.py')
    for c in cands:
        if os.path.isfile(c):
            metrics = os.path.join(os.path.dirname(c), 'metrics.py')
            with open(metrics, encoding='utf-8') as f:
                if 'def _dia(' not in f.read():
                    print(f'DEPENDENCIA: {os.path.abspath(c)} é uma versão antiga, sem ticket e frete por dia. '
                          'Instale a versão atualizada da skill gerar-relatorio-checkout-sentry-json.')
                    sys.exit(4)
            return os.path.abspath(c)
    print('DEPENDENCIA: skill gerar-relatorio-checkout-sentry-json não encontrada.')
    sys.exit(4)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--checkouts')
    ap.add_argument('--clientes')
    ap.add_argument('--raiz', default=os.getcwd())
    a = ap.parse_args()

    # ---------- checkouts ----------
    if a.checkouts:
        if not os.path.isfile(a.checkouts):
            falta(f'arquivo de checkouts não encontrado: {a.checkouts}')
        info, erro = checar_checkouts(a.checkouts)
        if erro:
            invalido(f'{a.checkouts}: {erro}')
        escolhido, outros = (a.checkouts, info), []
    else:
        cands = glob.glob(os.path.join(UPLOADS, '*.json')) + \
                glob.glob(os.path.join(a.raiz, 'Análises', 'CheckoutSentry', 'checkouts_*.json'))
        validos, recusados = [], []
        for c in cands:
            info, erro = checar_checkouts(c)
            (validos if info else recusados).append((c, info or erro))
        if not validos:
            for c, e in recusados:
                print(f'RECUSADO: {c}: {e}')
            falta('JSON de checkouts coletado pela skill coletar-checkouts-sentry (checkouts_<loja>_<periodo>_<data>.json). '
                  'Anexe o arquivo ou rode a coleta.')
        validos.sort(key=lambda x: os.path.getmtime(x[0]), reverse=True)
        escolhido, outros = validos[0], validos[1:]

    # ---------- clientes ----------
    arquivos = []
    if a.clientes:
        if os.path.isdir(a.clientes):
            arquivos = sorted(glob.glob(os.path.join(a.clientes, '*.csv')))
        elif os.path.isfile(a.clientes):
            arquivos = [a.clientes]
        if not arquivos:
            falta(f'nenhum CSV de clientes em {a.clientes}')
        ruins = [(p, eh_clientes(p)[1]) for p in arquivos if not eh_clientes(p)[0]]
        if ruins:
            invalido('; '.join(f'{p}: não é export de clientes da Shopify (faltam colunas: {", ".join(f)})' for p, f in ruins))
    else:
        cands = glob.glob(os.path.join(UPLOADS, '*.csv')) + \
                glob.glob(os.path.join(a.raiz, 'BaseDeClientes', '**', '*.csv'), recursive=True)
        arquivos = sorted(p for p in cands if eh_clientes(p)[0])
        if not arquivos:
            falta('export de clientes da Shopify em CSV (Clientes > Exportar, com as colunas '
                  + ', '.join(CLI) + '). Anexe o arquivo ou coloque em BaseDeClientes/.')
    if len(arquivos) == 1:
        caminho_cli = arquivos[0]
    else:
        # o kpis.py lê uma pasta: junta os CSVs válidos numa pasta temporária de links
        pasta = tempfile.mkdtemp(prefix='raio-x-clientes-')
        for i, p in enumerate(arquivos):
            os.symlink(os.path.abspath(p), os.path.join(pasta, f'{i:02d}_{os.path.basename(p)}'))
        caminho_cli = pasta

    kpis = achar_kpis(a.raiz)

    c, info = escolhido
    print(f'CHECKOUTS: {os.path.abspath(c)} | loja={info["loja"]} | periodo={info["periodo"]} | '
          f'exportado_em={info["exportado_em"]} | checkouts={info["coletado"]}/{info["disponivel"]}')
    for o, _ in outros:
        print(f'OUTROS_CHECKOUTS: {os.path.abspath(o)}')
    if info['moedas']:
        print('MOEDA_NO_ARQUIVO: ' + ', '.join(info['moedas']))
    print(f'CLIENTES: {os.path.abspath(caminho_cli)} | arquivos={len(arquivos)} | cadastros={contar_linhas(arquivos)}')
    print(f'KPIS_SCRIPT: {kpis}')
    print('OK')


if __name__ == '__main__':
    main()

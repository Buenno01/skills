"""Monta o Raio-X do checkout: injeta o JSON de KPIs e a narrativa no template fixo.

Uso:
    python3 montar.py --kpis kpis-checkouts-<data>.json --narrativa narrativa.json --saida raio-x.html

A narrativa é o único texto escrito pelo agente (títulos-conclusão e contextos). Números, destaques,
gráficos e tabelas saem do template a partir dos KPIs, sempre iguais. Formato em references/SECOES.md.
"""
import argparse
import html as htmllib
import json
import os
import re
import sys
from datetime import datetime, timezone

AQUI = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(AQUI, '..', 'assets', 'template.html')
VERSAO = '1.0.0'
SECOES = ['visao_geral', 'frete', 'estados', 'pagamento', 'cupons', 'produtos', 'combinacoes',
          'recuperacao', 'formulario', 'tendencia']
BLOCOS = ['avisos', 'fonte', 'periodo', 'taxa_abandono', 'pessoas', 'desfecho', 'funil', 'parou', 'frete',
          'regioes', 'pagamento', 'erros', 'produtos', 'combinacoes', 'clientes', 'por_dia']
TRAVESSAO = re.compile(r'[\u2014\u2013]')
EMAIL = re.compile(r'[\w.+-]+@[\w-]+\.[\w.]+')
TELEFONE = re.compile(r'\+?\d[\d\s().-]{8,}\d')


def erro(msg):
    sys.exit(f'ERRO: {msg}')


def textos(narr):
    yield 'titulo', narr.get('titulo', '')
    yield 'subtitulo', narr.get('subtitulo', '')
    for k, v in (narr.get('secoes') or {}).items():
        yield f'secoes.{k}.titulo', (v or {}).get('titulo', '')
        yield f'secoes.{k}.contexto', (v or {}).get('contexto', '')


def validar_narrativa(narr):
    problemas = []
    sec = narr.get('secoes') or {}
    for k in SECOES:
        s = sec.get(k) or {}
        if not (s.get('titulo') or '').strip():
            problemas.append(f'secoes.{k}.titulo vazio (o título deve ser uma conclusão)')
        if not (s.get('contexto') or '').strip():
            problemas.append(f'secoes.{k}.contexto vazio')
        if len(s.get('titulo') or '') > 100:
            problemas.append(f'secoes.{k}.titulo com mais de 100 caracteres')
        if len(s.get('contexto') or '') > 420:
            problemas.append(f'secoes.{k}.contexto com mais de 420 caracteres')
    extras = [k for k in sec if k not in SECOES]
    if extras:
        problemas.append('seções desconhecidas: ' + ', '.join(extras))
    for campo, t in textos(narr):
        if TRAVESSAO.search(t or ''):
            problemas.append(f'{campo}: travessão como recurso de estilo (troque por vírgula, dois pontos ou ponto)')
        if EMAIL.search(t or '') or TELEFONE.search(t or ''):
            problemas.append(f'{campo}: parece conter e-mail ou telefone')
    return problemas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--kpis', required=True)
    ap.add_argument('--narrativa', required=True)
    ap.add_argument('--saida', required=True)
    a = ap.parse_args()

    with open(a.kpis, encoding='utf-8') as f:
        kpis = json.load(f)
    faltam = [b for b in BLOCOS if b not in kpis]
    if faltam:
        erro('JSON de KPIs incompleto (faltam: ' + ', '.join(faltam) + '). Gere de novo com a versão atual do kpis.py.')
    if kpis['por_dia'] and 'ticket_medio' not in kpis['por_dia'][0]:
        erro('KPIs gerados por versão antiga do kpis.py (por_dia sem ticket e frete). Atualize a skill base e gere de novo.')

    with open(a.narrativa, encoding='utf-8') as f:
        narr = json.load(f)
    problemas = validar_narrativa(narr)
    if problemas:
        erro('narrativa com problemas:\n  - ' + '\n  - '.join(problemas))

    dados = {'versao': VERSAO, 'gerado_em': datetime.now(timezone.utc).isoformat(), 'kpis': kpis, 'narrativa': narr}
    embutido = json.dumps(dados, ensure_ascii=False).replace('</', '<\\/')
    with open(TEMPLATE, encoding='utf-8') as f:
        html = f.read()
    if '/*__DADOS__*/' not in html:
        erro('template sem o marcador /*__DADOS__*/')
    html = html.replace('/*__DADOS__*/', embutido).replace('__VERSAO__', VERSAO)
    titulo = (narr.get('titulo') or 'Raio-X do checkout') + (f" · {kpis['fonte'].get('loja')}" if kpis['fonte'].get('loja') else '')
    html = html.replace('<title>Raio-X do checkout</title>', f'<title>{htmllib.escape(titulo)}</title>', 1)

    os.makedirs(os.path.dirname(os.path.abspath(a.saida)), exist_ok=True)
    with open(a.saida, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f'HTML: {os.path.abspath(a.saida)} ({len(html.encode()) / 1024:.0f} KB) · padrão v{VERSAO}')
    for av in kpis.get('avisos') or []:
        print(f'AVISO: {av}')


if __name__ == '__main__':
    main()

---
name: raio-x-checkout
description: >
  Gera o Raio-X do checkout, o relatório padrão da Shakers sobre abandono de checkout: uma página única com
  cabeçalho, 10 seções fixas (visão geral, frete, estados, pagamento, cupons, produtos, combinações de carrinho,
  recuperação, formulário, tendência) e rodapé de metodologia, publicada como artefato na identidade visual Shakers.
  Usa exclusivamente o JSON coletado pela skill coletar-checkouts-sentry cruzado com o export de clientes da Shopify,
  e calcula os números com a skill gerar-relatorio-checkout-sentry-json. Acione sempre que ouvir "raio-x do checkout",
  "relatório de checkout", "relatório do Checkout Sentry", "análise de abandono de checkout", "monta o relatório de
  checkouts", "por que o checkout está abandonando", "relatório de recuperação de carrinho", ou quando alguém anexar um
  checkouts_*.json com uma base de clientes e pedir análise, mesmo sem dizer "raio-x". Se faltar qualquer uma das duas
  entradas, a skill para e pede.
argument-hint: "[checkouts_<loja>_<periodo>_<data>.json] [export de clientes .csv ou pasta] [url do artefato para atualizar]"
---

# Raio-X do checkout

Esta skill define **o que** o relatório mostra e **para que** cada seção existe. O cálculo é da skill
`gerar-relatorio-checkout-sentry-json` (script `kpis.py`). A página é um template fixo (`assets/template.html`) que
gera números, destaques, gráficos e tabelas a partir do JSON de KPIs. O único texto escrito por você é a
**narrativa**: o título-conclusão e o contexto de cada seção. Por isso todo relatório sai com a mesma estrutura,
e melhorar o padrão é mudar o template e a spec uma vez só.

Arquivos de apoio, leia antes de escrever a narrativa:
- `references/SECOES.md`: cada seção, os blocos do JSON que ela usa, o que o template mostra, o objetivo e a receita do título.
- `references/PADROES.md`: cores semânticas, convenções de apresentação e regras de escrita da narrativa.
- `examples/narrativa-exemplo.json`: formato da narrativa.

## Passo 0. Entradas (obrigatório, bloqueante)

O relatório só roda com as duas entradas abaixo. Não existe relatório parcial, dado de exemplo ou estimativa.

1. **JSON do Checkout Sentry** gravado pela skill `coletar-checkouts-sentry` (`checkouts_<loja>_<periodo>_<data>.json`).
   Outro formato (JSONL, CSV do Sentry, export manual) é recusado.
2. **Export de clientes da Shopify** em CSV (Clientes > Exportar), com as colunas `Customer ID`, `Email`, `Phone`,
   `Default Address Phone`, `Accepts Email Marketing`, `Accepts SMS Marketing`, `Accepts WhatsApp Marketing`, `Total Orders`.

Rode o gate, a partir da raiz do projeto (ou de onde estiverem os arquivos). Passe os caminhos se o usuário indicou algum:

```
python3 <esta skill>/scripts/validar.py [--checkouts ARQUIVO.json] [--clientes CSV_OU_PASTA]
```

Sem caminhos, ele procura nos anexos da conversa (`/mnt/user-data/uploads`), em `Análises/CheckoutSentry/` e em `BaseDeClientes/`.

| Saída | O que fazer |
|---|---|
| `FALTA:` (código 2) | **Pare aqui.** Diga ao usuário exatamente qual arquivo falta, usando a mensagem do gate, e peça que anexe ou indique o caminho. Se faltar o JSON, ofereça rodar a skill `coletar-checkouts-sentry` (ela precisa da URL do Checkout Sentry). Não siga até receber. |
| `INVALIDO:` (código 3) | **Pare aqui.** Mostre o motivo e peça o arquivo certo. Não tente converter nem adaptar o arquivo recusado. |
| `DEPENDENCIA:` (código 4) | **Pare aqui.** A skill `gerar-relatorio-checkout-sentry-json` não está instalada ou está numa versão antiga. Informe o usuário. |
| `OUTROS_CHECKOUTS:` | Há mais de um JSON válido. Liste os nomes (loja, período, data) e pergunte qual usar antes de seguir. |
| `MOEDA_NO_ARQUIVO:` | O próprio checkout traz a moeda em campo estruturado. Use esse valor como rótulo no passo 1. |
| `OK` | Siga. Guarde `CHECKOUTS`, `CLIENTES` e `KPIS_SCRIPT`. Diga em uma linha quais arquivos vai usar. |

## Passo 1. Calcular

```
python3 <KPIS_SCRIPT> <CHECKOUTS> --clientes <CLIENTES> [--currency SÍMBOLO] --saida <pasta de trabalho>/kpis.json
```

Moeda: passe `--currency` só quando ela for conhecida. Vale, nesta ordem, o que o usuário disser, o `MOEDA_NO_ARQUIVO`
do gate ou uma inferência óbvia a partir dos dados (por exemplo, todos os telefones com +55 e todas as UFs brasileiras
indicam `R$`). Na dúvida, não passe a flag: o rótulo fica `$`. O rótulo não converte valores.
Se sair `ERRO:`, mostre a mensagem e encerre. As linhas `AVISO:` vão para o cabeçalho automaticamente.

## Passo 2. Escrever a narrativa

Leia o `kpis.json`, `references/SECOES.md` e `references/PADROES.md`. Escreva `narrativa.json` com `titulo`,
`subtitulo` e, para cada uma das 10 seções, `titulo` (a conclusão da seção) e `contexto` (uma a três frases).

- Use só números do `kpis.json`. Não recalcule, não estime, não arredonde para mudar o sentido.
- O relatório mostra tudo o que veio nos dados. Não exclua, filtre nem selecione checkouts, produtos, cupons, fretes ou UFs,
  nem mesmo os que pareçam teste ou desenvolvimento: essa poluição faz parte da operação e fica no relatório.
- Não interprete texto livre para criar categorias. Mensagens de erro, nomes de produto, de frete e de cupom aparecem como vieram.
- Título é conclusão, não rótulo: "O pagamento concentra a maior perda" e não "Pagamentos".
- Taxa com `amostra_pequena: true` não sustenta conclusão. Se a seção inteira for amostra pequena ou vazia, o título diz isso.
- Nada de nome, e-mail ou telefone. Sem travessão como recurso de estilo.

## Passo 3. Montar

```
python3 <esta skill>/scripts/montar.py --kpis <pasta>/kpis.json --narrativa <pasta>/narrativa.json --saida <pasta>/raio-x-<loja>-<AAAA-MM-DD>.html
```

O script recusa narrativa incompleta, com travessão, com dado pessoal ou longa demais. Corrija e rode de novo.
Não edite o HTML gerado: qualquer ajuste de apresentação vai para o template (veja "Evoluir o padrão").

## Passo 4. Entregar

- Com a ferramenta Artifact disponível: publique o HTML (`title` "Raio-X do checkout · <loja>", `favicon` 🔎). Para
  atualizar um relatório já publicado da mesma loja, passe a `url` dele; sem `url`, a publicação cria um novo.
- Sem a ferramenta (Claude Code, Cowork): salve em `Análises/CheckoutSentry/` e informe o caminho. Essa pasta fica fora do repositório.
- Na resposta, em prosa curta: as duas ou três conclusões principais, os avisos de qualidade do cabeçalho e o link ou caminho. Sem repetir o relatório.

## Evoluir o padrão

O relatório tem versão (`VERSAO` em `scripts/montar.py`, exibida no rodapé). Para mudar o padrão:
1. Mude a spec em `references/SECOES.md` ou `references/PADROES.md`.
2. Mude o template em `assets/template.html` para refletir a spec. Número novo exige campo novo no `kpis.py` da skill base, com teste.
3. Suba a versão em `montar.py` e registre em `CHANGELOG.md`.
Mudanças que o usuário pedir para um relatório só (um recorte, uma pergunta pontual) não mudam o padrão: responda na conversa.

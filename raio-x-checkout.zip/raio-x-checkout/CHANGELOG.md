# Changelog do padrão Raio-X do checkout

Registro de mudanças a partir da entrada em produção. A versão aparece no rodapé de cada relatório (`VERSAO` em `scripts/montar.py`).
